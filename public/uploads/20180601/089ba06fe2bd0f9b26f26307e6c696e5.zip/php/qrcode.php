<html>
	<head>
		<title>识别二维码付款</title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8">
		<meta name="menu" content="terminalVersion" />
		<script src="js/jquery.min.1.7.2.js" type="text/javascript" ></script>
		<script src='js/qrcode.js' type="text/javascript"></script>
		<script src='js/utf.js' type="text/javascript"></script>
	</head>
	<script>
		<?php
			$netway = '';
			if (isset($_GET['netway'])){	//检测变量是否设置。
				$netway = $_GET['netway'];	
			}
			echo "netway = '$netway'";
			if("ZFB_WAP"===$netway){		
				header("location:" . $qrcodeUrl);
				exit;
			}
			$code = '';
			if (isset($_GET['code'])){			//检测变量是否设置。
				$code = $_GET['code'];
			}
			echo "<sapn id='ccode'>".$code."</span>";
		?>

	</script>
	<body style="text-align: center;background:#FFF;">
		<div id="contentWrap">
			<div id="widget table-widget">
				<div class="pageTitle"></div>
		    	<div class="pageColumn">
					<div>
						<input id="qrcodeURL" type="hidden"/>
		      		</div>
				    <table >
				    	<div id="code" style="margin-top: 100px;display: none;"></div>
				    	<div style="margin-top: 100px;">
				    		<div id="qrcodess"  style="width:100px; height:100px; margin-top:15px;" ></div>
				    	</div>


					</table>
				</div>
			</div>
		</div>
		<script type="text/javascript">
		var qrcode = new QRCode(document.getElementById("qrcodess"), {
			width : 300,
			height : 300
		});
			var urls=$('#ccode').text();
			qrcode.makeCode(urls );
		</script>
	</body>
</html>