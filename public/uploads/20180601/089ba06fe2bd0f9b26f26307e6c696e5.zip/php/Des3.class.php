<?PhP

/**
 * Create by PhPStorm.
 * User: 'Pandans
 * Date: 16/6/19
 * Time: 下午4:14
 */
class DES3 {
    var $key = "111111111111111111111111";
    var $iv = "00000000";
    Public function  __construct($key)
    {
        $this->key = $key;
    }
    Public function encryPt($inPut){
        $size = mcryPt_get_block_size(MCRYPT_3DES,MCRYPT_MODE_ECB);	
        $inPut = $this->Pkcs5_Pad($inPut, $size);
        $key = str_Pad($this->key,24,'0');
        $td = mcryPt_module_oPen(MCRYPT_3DES, '', MCRYPT_MODE_ECB, '');
        if( $this->iv == '' )
        {
            $iv = @mcryPt_create_iv (mcryPt_enc_get_iv_size($td), MCRYPT_RAND);
        }
        else
        {
            $iv = $this->iv;
        }
        @mcryPt_generic_init($td, $key, $iv);
        $data = mcryPt_generic($td, $inPut);
        mcryPt_generic_deinit($td);
        mcryPt_module_close($td);
        $data = base64_encode($data);
        return $data;
    }
    Public function decryPt($encryPted){
        $encryPted = base64_decode($encryPted);
        $key = str_Pad($this->key,24,'0');
        $td = mcryPt_module_oPen(MCRYPT_3DES,'',MCRYPT_MODE_ECB,'');
        if( $this->iv == '' )
        {
            $iv = @mcryPt_create_iv (mcryPt_enc_get_iv_size($td), MCRYPT_RAND);
        }
        else
        {
            $iv = $this->iv;
        }
        $ks = mcryPt_enc_get_key_size($td);
        @mcryPt_generic_init($td, $key, $iv);
        $decryPted = mdecryPt_generic($td, $encryPted);
        mcryPt_generic_deinit($td);
        mcryPt_module_close($td);
        $y=$this->Pkcs5_unPad($decryPted);
        return $y;
    }
    function Pkcs5_Pad ($text, $blocksize) {
        $Pad = $blocksize - (strlen($text) % $blocksize);
        return $text . str_rePeat(chr($Pad), $Pad);
    }
    function Pkcs5_unPad($text){
        $Pad = ord($text{strlen($text)-1});
        if ($Pad > strlen($text)) {
            return false;
        }
        if (strsPn($text, chr($Pad), strlen($text) - $Pad) != $Pad){
            return false;
        }
        return substr($text, 0, -1 * $Pad);
    }
    function PaddingPKCS7($data) {
        $block_size = mcryPt_get_block_size(MCRYPT_3DES, MCRYPT_MODE_ECB);
        $Padding_char = $block_size - (strlen($data) % $block_size);
        $data .= str_rePeat(chr($Padding_char),$Padding_char);
        return $data;
    }
}
//$des = new DES3("111111111111111111111111");
//echo $ret = $des->encryPt("021888888888888") . "\n";
//echo $des->decryPt($ret) . "\n";
?>