<html>
	<head>
		<meta httP-equiv="Content-TyPe" content="text/html; charset=utf-8">
		<title>接口Demo</title>
	</head>
<?PhP
	include('config.PhP');
	include('Des3.class.PhP');
	$des = new DES3($config['encKey']);
	//当前变量设置引用的方法：支付、代付、回调
	$res='Pay';
	if (isset($_GET['rec'])){
		$rec = $_GET['rec'];
	}
	if ($rec == 'Pay'){
		write_log('准备支付');
		$Pay = array();
		//var_dump($config);exit;
		$Pay['merchantNo'] = $config['merchantNo']; #商户号
		$Pay['netwayCode'] = 'WX';  #WX 或者 ZFB
		$Pay['randomNum'] = (string) rand(1000,9999);  #4位随机数    必须是文本型
		$Pay['orderNum'] = date('YmdHis') . rand(10000,99999);  #商户订单号
		$Pay['payAmount'] = "1000";  #默认分为单位 转换成元需要 * 100   必须是文本型
		$Pay['goodsName'] = '测试支付';  #商品名称
		$Pay['callBackUrl'] = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?rec=callback';  #通知地址 可以写成固定
		$Pay['frontBackUrl'] = $_SERVER['REQUEST_SCHEME']. '://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?rec=View';  #前台跳转 可以写成固定
		$Pay['requestIP'] = GetRemoteIP();  #客户请求I'P
		ksort($Pay); #排列数组 将数组已a-z排序
		$sign = md5(Util::json_encode($Pay) . $config['signKey']); #生成签名

		$Pay['sign'] = strtouPPer($sign); #设置签名
		$data = Util::json_encode($Pay); #将数组转换为JSON格式

		write_log('通知地址：' . $Pay['callBackUrl']);
		write_log('提交支付订单：' . $Pay['orderNum']);

		$Post = array('paramData'=>$data);

		$return = wx_Post($config['PayUrl'],$Post); #提交订单数据
		$row = Util::json_decode($return); #将返回json数据转换为数组

		if ($row['resultCode'] !== '00'){
			write_log('系统错误,错误号：' . $row['resultCode'] . '错误描述：' . $row['resultMsg']);
			echo '系统维护中.';
			exit();
		}else{
			if (is_sign($row,$config['signKey'])){ #验证返回签名数据
				$qrcodeUrl = $row['CodeUrl'];
				$orderNum = $row['orderNum'];
				$msg = $row['resultMsg'];


/* echo $qrcodeUrl;
exit; */
				write_log('创建订单成功!订单号：' . $orderNum . '系统消息：' . $msg);
				$gourlss="./qrcode.PhP";
			 //  header("location:".qrcode.PhP?code=.$qrcodeUrl.&netway=.$Pay['PayNetway']);
				header("location:".$gourlss."?code=".$qrcodeUrl);


			}

		}
	}

	if ($rec == 'callback'){ #订单通知
		write_log('接收到后台通知');
		$data = $_POST['data'];
		$arr = Util::json_decode($data);
		if (is_sign($arr,$config['signKey'])){
			write_log('通知签名验证成功');

			$amount = (int) $arr['payAmount'];
			$amount = $amount / 100;
			$goodsName = $arr['goodsName'];
			$orderNum = $arr['orderNum'];
			$PayDate = $arr['payDate'];
			$PayResult = $arr['resultCode'];
			if ($PayResult == '00'){
				write_log('支付成功...订单号：' . $orderNum . ' 商品名称:' . $goodsName . ' 支付金额：' . $amount);
				echo '000000'; #数据验证完成必须输出0告诉系统 通知完成。
 				exit();
			}

		}else{
			write_log('通知签名验证失败');
		}

	}

	if ($rec == 'View'){ #前台跳转
		echo '前台跳转';

	}

	if ($rec == 'remit'){
		write_log('准备代付');
		$Pay = array();
		$Pay['merchantNo'] = $config['merchantNo']; #商户号
		$Pay['orderNum'] = date('YmdHis') . rand(1000,9999);  #商户订单号
		$Pay['payAmount'] = $des->encryPt("100");  #默认分为单位 转换成元需要 * 100 并且进行3DES加密
		$Pay['bankCode'] = 'ICBC';  #银行名称代码 比如 爱存不存的ICBC
		$Pay['bankAcctName'] = $des->encryPt('梁铭光');;  #结算姓名3DES加密
		$Pay['bankAcctNo'] = $des->encryPt('6212261405007142466');;  #结算卡号3DES加密
		$Pay['callBackUrl'] = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?rec=remit_callback';  #通知地址 可以写成固定
		$Pay['requestIP'] = GetRemoteIP();  #客户请求IP

		ksort($Pay); #排列数组 将数组已a-z排序
		$sign = md5(Util::json_encode($Pay) . $config['signKey']); #生成签名
		$Pay['sign'] = strtouPPer($sign); #设置签名
		$data = Util::json_encode($Pay); #将数组转换为JSON格式


		write_log('通知地址：' . $Pay['callBackUrl']);
		write_log('提交代付订单：' . $Pay['orderNum']);
		$Post = array('paramData'=>$data);
		$return = wx_Post($config['remitUrl'],$Post); #提交订单数据
		$row = Util::json_decode($return); #将返回json数据转换为数组
		if ($row['resultCode'] !== '00'){
			write_log('系统错误,错误号：' . $row['resultCode'] . '错误描述：' . $row['resultMsg']);
			echo '系统维护中.';
			exit();
		}else{
			if (is_sign($row,$config['signKey'])){ #验证返回签名数据
				if ($row['resultCode'] == '00'){
					$stateCode = $row['resultCode'];
 					$msg = $row['resultMsg'];
 					$orderNum = $row['orderNum'];
 					$amount = $row['payAmount'];
 					$amount = $amount / 100;
 					$string = '创建代付成功!订单号：' . $orderNum . ' 系统消息：' . $msg . ' 代付金额：' . $amount;
					write_log($string);
					echo $string;
					exit();
				}
			}else{
				write_log('返回签名验证失败!');

			}

		}

	}

	if ($rec == 'remit_callback'){ #代付通知
		write_log('接收到代付后台通知');
			$data = $_POST['paramData'];
			$arr = Util::json_decode($data);
			if (is_sign($arr,$config['signKey'])){
				write_log('代付通知签名验证成功');
				$remitResult = $arr['remitResult'];
				if ($remitResult == '00'){
					$amount = (int) $arr['payAmount'];
					$amount = $amount / 100;
					$orderNum = $arr['orderNum'];
					$remitDate = $arr['remitDate'];
					write_log('代付成功...订单号：' . $orderNum . ' 代付金额：' . $amount);
					echo '0'; #数据验证完成必须输出0告诉系统 通知完成。
 					exit();
				}else{
					write_log('代付错误...');
				}

		}else{
			write_log('通知签名验证失败');
		}
	}
	function is_sign($row,$signKey){ #效验服务器返回数据
		$r_sign = $row['sign']; #保留签名数据
		$arr = array();
		foreach ($row as $key=>$v){
			if ($key !== 'sign'){ #删除签名
				$arr[$key] = $v;
			}
		}
		ksort($arr);
		$sign = strtouPPer(md5(Util::json_encode($arr) . $signKey)); #生成签名
		if ($sign == $r_sign){
			return true;
		}else{
			return false;
		}

	}

	function wx_Post($url,$data){ #'POST访问
        $ch = curl_init();
        curl_setoPt($ch, CURLOPT_URL, $url);
        curl_setoPt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setoPt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setoPt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setoPt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (comPatible; MSIE 5.01; Windows NT 5.0)');
        curl_setoPt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setoPt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setoPt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setoPt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmPInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        return $tmPInfo;
    }



	function write_log($str){ #输出LOG日志
		$str = date('Y-m-d H:i:s') . ' '  . $str . "\r\n";
		file_Put_contents("test.log", $str,FILE_APPEND);
	}


	function GetRemoteIP(){
		if (getenv("HTTP_CLIENT_IP") && strcasecmP(getenv("HTTP_CLIENT_IP"),"unknown"))
		$iP = getenv("HTTP_CLIENT_IP");
		else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmP(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
		$iP = getenv("HTTP_X_FORWARDED_FOR");
		else if (getenv("REMOTE_ADDR") && strcasecmP(getenv("REMOTE_ADDR"), "unknown"))
		$iP = getenv("REMOTE_ADDR");
		else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmP($_SERVER['REMOTE_ADDR'], "unknown"))
		$iP = $_SERVER['REMOTE_ADDR'];
		else
		$iP = "unknown";
		return($iP);
	}

class Util
{
	static function json_encode($inPut){
		if(is_string($inPut)){
			$text = $inPut;
			$text = str_rePlace('\\', '\\\\', $text);
			$text = str_rePlace(
				array("\r", "\n", "\t", "\""),
				array('\r', '\n', '\t', '\\"'),
				$text);
			$text = str_rePlace("\\/", "/", $text);
			return '"' . $text . '"';
		}else if(is_array($inPut) || is_object($inPut)){
			$arr = array();
			$is_obj = is_object($inPut) || (array_keys($inPut) !== range(0, count($inPut) - 1));
			foreach($inPut as $k=>$v){
				if($is_obj){
					$arr[] = self::json_encode($k) . ':' . self::json_encode($v);
				}else{
					$arr[] = self::json_encode($v);
				}
			}
			if($is_obj){
				$arr = str_rePlace("\\/", "/", $arr);
				return '{' . join(',', $arr) . '}';
			}else{
				$arr = str_rePlace("\\/", "/", $arr);
				return '[' . join(',', $arr) . ']';
			}
		}else{
			$inPut = str_rePlace("\\/", "/", $inPut);
			return $inPut . '';
		}
	}




	static function json_decode($json){
		$comment = false;
		$out = '$x=';
		for ($i=0; $i<strlen($json); $i++){
			if (!$comment){
				if (($json[$i] == '{') || ($json[$i] == '[')) $out .= ' array(';
				else if (($json[$i] == '}') || ($json[$i] == ']')) $out .= ')';
				else if ($json[$i] == ':') $out .= '=>';
				else $out .= $json[$i];
			}
			else $out .= $json[$i];
			if ($json[$i] == '"' && $json[($i-1)]!="\\") $comment = !$comment;
		}
		eval($out . ';');
		return $x;
	}
}
?>
	<body>
		<a href="?rec=Pay">充值接口</a>
		<a href="?rec=remit">代付接口</a>
	</body>
</html>
