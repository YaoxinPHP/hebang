<?PhP
	$config = array(
		'merchantNo'=>'DR180306093',
		'signKey'=>'07F7D01D86B3F454E7E55D569',
		'encKey'=>'2107863436164132547',
		'PayUrl'=>'http://defray.948pay.com:8188/api/smPay.action',
		'remitUrl'=>'http://defray.948pay.com:8188/api/remit.action',
	);
?>